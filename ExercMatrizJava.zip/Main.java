import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    int mat[][] = new int[3][3];

    System.out.println("Digite os elementos da matriz:");
    for(int i=0; i<mat.length; i++){
      for(int j=0; j<mat.length; j++){
        System.out.println("Digite o elemento: "+i+","+j);
        mat[i][j] = scan.nextInt();
      }
    }

    System.out.println("Os elementos da matriz são:");
    for(int i=0; i<mat.length; i++){
      for(int j=0; j<mat.length; j++){
        System.out.print(mat[i][j]);
      }
      System.out.println();
    }

  }
}